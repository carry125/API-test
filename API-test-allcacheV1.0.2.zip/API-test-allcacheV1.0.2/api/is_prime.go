package api

import (
	"strconv"
	"test/cache"
	"test/calculator"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(c *gin.Context) {
	start := c.PostForm("numStart")
	end := c.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	if numStart < 0 || numEnd < 0 {
		c.JSON(400, gin.H{"error": "Invalid value"})
		return
	}
	if numStart > numEnd {
		swapStart, swapEnd := calculator.Swap(numStart, numEnd)
		//cache.UpdateCachePrimeRange(swapStart, swapEnd)
		interval, _ := cache.QueryCachePrimesInRange(swapStart, swapEnd)
		c.JSON(200, gin.H{"prime_values": interval})
		return
	}
	//
	interval, err := cache.QueryCachePrimesInRange(numStart, numEnd) // 針對這錯誤寫if
	//cache.UpdateCachePrimeRange(numStart, numEnd)                    //經過還要在資料庫和cache 更新
	c.JSON(200, gin.H{"prime_values": interval})
}
