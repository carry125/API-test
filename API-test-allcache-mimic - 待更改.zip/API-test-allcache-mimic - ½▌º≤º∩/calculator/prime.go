package calculator

func IsPrime(numberInterval int) bool {
	if numberInterval < 2 {
		return false
	}
	for i := 2; i < numberInterval; i++ {
		if numberInterval%i == 0 {
			return false
		}
	}
	return true
}
func Calculate(numStart int, numEnd int) []int {
	var numberGroup []int
	if numStart > numEnd {
		numStart, numEnd = Swap(numStart, numEnd)
	}
	// 進行計算
	for i := numStart; i <= numEnd; i++ {
		if IsPrime(i) {
			numberGroup = append(numberGroup, i)
		}
	}
	return numberGroup
}
func Swap(numStart int, numEnd int) (start int, end int) {
	temp := numStart
	numStart = numEnd
	numEnd = temp

	start = numStart
	end = numEnd
	return start, end
}
