package formdata

var FormData = []struct {
	NumStart string
	NumEnd   string
}{
	{"20", "13"},
	{"#", "13"},
	{"1", "60"},
	{"100#1", "13"},
	{"abc", "def"},
	{"1", "10000"},
	{"-13", "13"},
	{"2.5", "7.8"},
	{" ", "7"},
	{"13", "13"},
	{"0", "0"},
}
