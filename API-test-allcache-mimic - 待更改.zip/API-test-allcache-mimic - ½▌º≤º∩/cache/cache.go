package cache

import (
	"test/calculator"
	"test/database"
	"time"

	"github.com/patrickmn/go-cache"
)

// 把質數表放入快取
type Prime struct {
	Value int
}

var cacheObject *cache.Cache

func init() {
	cacheObject = cache.New(5*time.Minute, 10*time.Minute)
}

func InitializeCachePrimes() {
	primesToCache := []int{} // 初始的质数列表
	cacheObject.Set("primes", primesToCache, cache.DefaultExpiration)
}

func QueryCachePrimesInRange(start int, end int) ([]int, error) { //輸出
	// 檢查快取中是否有存在區間中的質數
	cachedPrimes, found := cacheObject.Get("primes")
	if found {
		primeTable := cachedPrimes.([]int)
		var primesInRange []int
		for _, prime := range primeTable {
			if prime >= start && prime <= end {
				primesInRange = append(primesInRange, prime)
			}
		}
		if len(primesInRange) > 0 {
			return primesInRange, nil
		}
	}
	primesInRange, find := database.QueryDBPrimesInRange(start, end) //if cache miss go DB
	if find != nil {
		return primesInRange, nil
	}
	err := UpdateCachePrimeRange(start, end)
	if err != nil {
		return nil, err
	}
	return QueryCachePrimesInRange(start, end) // 重新查询缓存，此时应该会找到更新后的数据
}
func UpdateCachePrimeRange(start int, end int) error {
	primeInRange := calculator.Calculate(start, end)
	if err := database.UpdateDBPrimeRange(start, end); err != nil {
		return err
	}
	cacheObject.Set("primes", primeInRange, cache.DefaultExpiration)
	return nil
}
