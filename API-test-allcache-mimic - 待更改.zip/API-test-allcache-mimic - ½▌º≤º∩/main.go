package main

import (
	"test/api"
	"test/cache"
	"test/server"

	"github.com/gin-gonic/gin"
)

func init() {
	server.SetupDatabaseConnection()

}

func main() {
	cache.InitializeCachePrimes()
	router := gin.Default()
	router.POST("/isPrimesToApi", api.CheckAndInsertPrimeValues) // 設置路由處理函式
	router.Run(":8080")
}

/*go func() {
	//cache.InitializeCachePrimes()
	router := gin.Default()
	router.POST("/isPrimesToApi", api.CheckAndInsertPrimeValues) // 設置路由處理函式
	router.Run(":8080")                                          //將計算結果回傳給API伺服器
}()
//等待一段時間，確保 API 伺服器有足夠的時間啟動
//time.Sleep(1 * time.Second)

/*for _, input := range formdata.FormData {
	url := "http://localhost:8080/isPrimesToApi"
	response, err := api.SendFormDataRequest(url, input.NumStart, input.NumEnd)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	fmt.Printf("輸入字元start=%s end=%s,回應= %s\n", input.NumStart, input.NumEnd, response)
}
select {}*/
