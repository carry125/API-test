package api

import (
	"strconv"
	"test/cache"
	"test/calculator"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(ctx *gin.Context) {
	start := ctx.PostForm("numStart")
	end := ctx.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		ctx.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		ctx.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	if numStart > numEnd {
		newStart, newEnd := calculator.Swap(numStart, numEnd)
		interval, _ := cache.CalculateAndCachePrimeRange(newStart, newEnd)
		//interval, _ := cache.QueryCachePrimesInRange(newStart, newEnd)
		ctx.JSON(200, gin.H{"prime_values": interval})
		return
	}
	if numStart <= 0 || numEnd <= 0 {
		ctx.JSON(400, gin.H{"error": "Invalid value"})
		return
	}
	if numStart == 1 && numEnd == 1 {
		ctx.JSON(400, gin.H{"error": "not prime"})
		return
	}
	interval, _ := cache.CalculateAndCachePrimeRange(numStart, numEnd)
	//interval, err := cache.QueryCachePrimesInRange(numStart, numEnd)
	ctx.JSON(200, gin.H{"prime_values": interval})
}
