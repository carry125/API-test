package database

import (
	"database/sql/driver"
	"encoding/json"
	"log"
	"test/server"
)

type JSON struct {
	Start string `json:"start"`
	End   string `json:"end"`
}
type IsPrime struct { //自定義輸出
	NumberInterval JSON `gorm:"TYPE:json"`
	PrimeValues    string
}

func (c JSON) Value() (driver.Value, error) { //建置JSON模式的value和scan
	b, err := json.Marshal(c)
	return string(b), err
}
func (c *JSON) Scan(input interface{}) error {
	return json.Unmarshal(input.([]byte), c)
}

func InsertPrimeValues(start string, end string, values string) {
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	/*if transact.Migrator().HasTable(&IsPrime{}) {
		fmt.Println("ok")
	} else {
		err := transact.AutoMigrate(&IsPrime{})
		if err != nil {
			log.Fatal(err)
		}
	}*/
	tableIsPrime := IsPrime{ //用變數將類別實體化
		NumberInterval: JSON{
			Start: start,
			End:   end,
		},
		PrimeValues: values,
	}
	tableInsert := transact.Debug().Create(&tableIsPrime)
	if tableInsert.Error != nil {
		transact.Rollback() //錯誤時返回上一動
		log.Fatal(tableInsert.Error)
	}
	transact.Commit() //使用commit才算是上傳這個事務
}

// "icon->'$.name' = (?)", names[4]
func CheckIfRepeatInsert(start string, end string) bool {
	var existingData IsPrime
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	if result := transact.Where("JSON_EXTRACT(number_interval, '$.start') = ? AND JSON_EXTRACT(number_interval, '$.end') = ?", start, end).First(&existingData); result.Error == nil {
		result.Rollback()
		return true
	}
	return false
}
func QueryInterval(start string, end string) []string {
	var primeValues []string
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	result := transact.Select("prime_values").Where("JSON_EXTRACT(number_interval, '$.start') = ? AND JSON_EXTRACT(number_interval, '$.end') = ?", start, end).Pluck("prime_values", &primeValues)
	if result.Error != nil {
		return nil
	}
	return primeValues
}
