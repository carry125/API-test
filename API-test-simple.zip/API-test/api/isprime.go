package api

import (
	"fmt"
	"strconv"
	"test/database"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(c *gin.Context) {
	start := c.PostForm("numStart")
	end := c.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	if numStart > numEnd {
		c.JSON(404, gin.H{"error": "區間不適用"})
	} else if numStart == numEnd {
		c.JSON(200, gin.H{"prime_values": "無"})
	}
	interval, _ := database.QueryPrimesInRange(numStart, numEnd) //將資料打包往資料庫傳送
	lastElement := interval[len(interval)-1]
	//fmt.Println(lastElement)
	if lastElement < numEnd {
		database.GenerateAndInsertPrimes(numEnd)
		newInterval, _ := database.QueryPrimesInRange(numStart, numEnd)
		fmt.Println(newInterval)
		c.JSON(200, gin.H{"prime_values": newInterval})
	} else if lastElement > numEnd {
		oldInterval, _ := database.QueryPrimesInRange(numStart, numEnd)
		c.JSON(200, gin.H{"prime_values": oldInterval})
	}
}
