package database

import (
	"test/calculator"
	"test/server"
)

type prime struct {
	ID    int `gorm:"primary_key"`
	Value int
}

func QueryPrimesInRange(start int, end int) ([]int, error) {
	var primes []int
	err := server.DateBaseConnection.Table("primes").
		Where("value >= ? AND value <= ?", start, end).
		Pluck("value", &primes).Error
	if err != nil {
		return nil, err
	}
	if len(primes) == 0 {
		// 如果沒有找到質數，返回一個空的切片
		return []int{}, nil
	}

	return primes, nil
}
func GenerateAndInsertPrimes(max int) error {
	// 在資料庫中找到最大的質數
	var maxPrime int
	err := server.DateBaseConnection.Table("primes").
		Select("value").Order("value DESC").Limit(1).
		Scan(&maxPrime).Error
	if err != nil {
		return err
	}

	// 從最大質數開始生成新的質數
	for num := maxPrime + 1; num <= max; num++ {
		if calculator.IsPrime(num) {
			// 插入新質數到資料庫
			err := server.DateBaseConnection.Create(&prime{Value: num}).Error
			if err != nil {
				return err
			}
		}
	}
	return nil
}
