package database

import (
	"log"
	"strconv"
	"test/calculator"
	"test/server"

	"gorm.io/gorm"
)

type Start struct {
	ID    uint `gorm:"primary_key;auto_increment"`
	Start int
}
type End struct {
	ID  uint `gorm:"primary_key;auto_increment"`
	End int
}
type Value struct { //自定義輸出
	ID      uint `gorm:"primary_key"`
	Value   string
	StartID uint `gorm:"foreignKey:StartID;references:ID"`
	EndID   uint `gorm:"foreignKey:EndID;references:ID"`
}

func GetOrCreateStartRecord(transact *gorm.DB, start int) (Start, error) { //確認start有無重複，並添加元素
	var existingStart Start
	if result := transact.Where("start = ?", start).First(&existingStart); result.Error != nil {
		startRecord := Start{Start: start}
		if err := transact.Create(&startRecord).Error; err != nil {
			return Start{}, err
		}
		existingStart = startRecord
	}
	return existingStart, nil
}

func GetOrCreateEndRecord(transact *gorm.DB, end int) (End, error) { //確認end有無重複，並添加元素
	var existingEnd End
	if result := transact.Where("end = ?", end).First(&existingEnd); result.Error != nil {
		endRecord := End{End: end}
		if err := transact.Create(&endRecord).Error; err != nil {
			return End{}, err
		}
		existingEnd = endRecord
	}
	return existingEnd, nil
}

func CheckIfValueExists(transact *gorm.DB, values string) bool { //確認value有無對應存在
	var existingData Value
	transact.Table("values").
		Where("value = ?", values).
		First(&existingData)
	return existingData.ID != 0
}

func CheckIfCombinationExists(transact *gorm.DB, startID, endID uint) bool { //確認value中兩個外來鍵有無重複
	var existingCombination Value
	transact.Table("values").
		Where("start_id = ? AND end_id = ?", startID, endID).
		First(&existingCombination)
	return existingCombination.ID != 0
}

func CheckAndInsertPrimeValues(start int, end int, values string) { //整體INSERT
	transact := server.DateBaseConnection.Begin()
	//transact.AutoMigrate(&Start{}, &End{}, &Value{})
	defer transact.Commit()

	existingStart, err := GetOrCreateStartRecord(transact, start)
	if err != nil {
		log.Fatal(err)
	}

	existingEnd, err := GetOrCreateEndRecord(transact, end)
	if err != nil {
		log.Fatal(err)
	}

	if CheckIfValueExists(transact, values) {
		return
	}

	if CheckIfCombinationExists(transact, existingStart.ID, existingEnd.ID) {
		transact.Rollback()
		return
	}

	valueRecord := Value{
		Value:   values,
		StartID: existingStart.ID,
		EndID:   existingEnd.ID,
	}
	tableInsert := transact.Debug().Create(&valueRecord)
	if tableInsert.Error != nil {
		transact.Rollback()
		log.Fatal(tableInsert.Error)
	}
}

func CheckIfRepeatInsert(start int, end int) bool { //搜尋start和end是否重複
	transact := server.DateBaseConnection.Begin()
	//defer transact.Commit()

	var count int64
	transact.Table("starts").Where("start = ?", start).Count(&count)
	if count > 0 {
		return true
	}

	transact.Table("ends").Where("end = ?", end).Count(&count)
	if count > 0 {
		return true
	}
	return false
}
func QueryInterval(start int, end int, values string) []string { //如有重複直接輸出，否則用join查詢
	var primeValues []string
	transact := server.DateBaseConnection.Begin()
	var existingData Value
	transact.Table("values").
		Where("value = ?", values).
		First(&existingData)
	if existingData.ID != 0 {
		a := calculator.Calculate(start, end)
		slice := make([]string, len(a))
		for i, num := range a {
			slice[i] = strconv.Itoa(num)
		}
		//result:=strings.Join(slice, "")
		return slice
	}
	// 使用 Join 進行聯結查詢
	result := transact.Debug().Table("values").
		Select("values.value").
		Joins("JOIN starts ON values.start_id = starts.ID").
		Joins("JOIN ends ON values.end_id = ends.ID").
		Where("starts.Start = ? AND ends.End = ?", start, end).
		Pluck("values.value", &primeValues)
	if result.Error != nil {
		return nil
	}
	return primeValues
}
