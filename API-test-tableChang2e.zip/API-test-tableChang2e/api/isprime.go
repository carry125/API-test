package api

import (
	"fmt"
	"strconv"
	"test/calculator"
	"test/database"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(c *gin.Context) {
	start := c.PostForm("numStart")
	end := c.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	primeValue := calculator.Calculate(numStart, numEnd)                //int 模式
	primeValueStr := fmt.Sprint(primeValue)                             //字串模式
	database.CheckAndInsertPrimeValues(numStart, numEnd, primeValueStr) // 確認資料，並儲存至資料庫

	if database.CheckIfRepeatInsert(numStart, numEnd) {
		primeQuery := database.QueryInterval(numStart, numEnd, primeValueStr)
		if primeQuery != nil {
			c.JSON(200, gin.H{"prime_values": primeQuery}) //輸出至前端
		} /*else {
			c.JSON(200, gin.H{"message": "資料已儲存"})
			//c.JSON(200, gin.H{"message": "資料已存在", "prime_values": primeQuery}) //如果不存在 加入並回傳
		}*/
	}
}
