package api

import (
	"strconv"
	"test/cache"
	"test/calculator"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(c *gin.Context) {
	start := c.PostForm("numStart")
	end := c.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	if numStart > numEnd {
		swapStart, swapEnd := calculator.Swap(numStart, numEnd)
		cache.UpdatePrimeRange(swapStart, swapEnd)
		interval, _ := cache.QueryPrimesInRange(swapStart, swapEnd)
		c.JSON(200, gin.H{"prime_values": interval})
		return
	}
	cache.UpdatePrimeRange(numStart, numEnd)                    //
	interval, err := cache.QueryPrimesInRange(numStart, numEnd) //
	c.JSON(200, gin.H{"prime_values": interval})
}
