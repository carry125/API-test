package main

import (
	"fmt"
	"test/api"
	"test/formdata"
	"test/server"

	"github.com/gin-gonic/gin"
)

func init() {
	server.SetupDatabaseConnection()
}

func main() {
	go func() {
		for _, input := range formdata.FormData {
			url := "http://localhost:8080/isPrimesToApi"
			response, err := api.SendFormDataRequest(url, input.NumStart, input.NumEnd)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			fmt.Printf("輸入字元start=%s end=%s,回應= %s\n", input.NumStart, input.NumEnd, response)
		}
	}()
	router := gin.Default()
	router.POST("/isPrimesToApi", api.CheckAndInsertPrimeValues) // 設置路由處理函式
	router.Run(":8080")                                          //將計算結果回傳給API伺服器
}
