package cache

import (
	"test/calculator"
	"time"

	"github.com/patrickmn/go-cache"
)

var (
	cacheObject *cache.Cache
)

func init() {
	cacheObject = cache.New(5*time.Minute, 10*time.Minute)
	cacheObject.Set("primes", []int{}, cache.DefaultExpiration) //init一個存在的cache
}
func GetPrimeCacheSlice() []int {
	primeCache, _ := cacheObject.Get("primes")
	primeCacheSlice := primeCache.([]int)
	return primeCacheSlice
}
func OutputCachePrimeRange(start int, end int) ([]int, error) { //沒有排序
	var outputInterval []int //輸出的答案
	primeCacheSlice := GetPrimeCacheSlice()
	for i := start; i <= end; i++ {
		if comparePrime(i, primeCacheSlice) == true { //可優化不要掃描那麼多次
			outputInterval = append(outputInterval, i) //跟放在cache裡面的比，是質數就放到輸出
		} else { //可優化
			if calculator.IsPrime(i) { //如果沒放在cache李，但他是質數
				outputInterval = append(outputInterval, i)   //更新output
				primeCacheSlice = append(primeCacheSlice, i) //更新cache
				//database.UpdateDBPrimeRange(start, end)      //cache miss
			}
		}
	}
	cacheObject.Set("primes", primeCacheSlice, cache.DefaultExpiration) //最後儲存至cacheObject
	return outputInterval, nil
}
func comparePrime(i int, primeslice []int) bool { //確認每個start到end的數，484cache裡存的質數
	for _, value := range primeslice {
		if i == value {
			return true
		}
	}
	return false
}

func mergeAndRemoveDuplicates(existing []int, newValues []int) []int { //關鍵
	existingMap := make(map[int]bool)
	merged := make([]int, 0, len(existing)+len(newValues))

	// 将 existing 切片中的元素添加到哈希集合中
	for _, val := range existing {
		existingMap[val] = true
		merged = append(merged, val)
	}

	// 将 newValues 切片中的不在哈希集合中的元素添加到 merged 切片中
	for _, val := range newValues {
		if !existingMap[val] {
			existingMap[val] = true
			merged = append(merged, val)
		}
	}

	return merged
}
func calculateAndGetInterface(start, end int) ([]int, []int, bool) { //当 cachedPrimes 不存在时，你试图将其强制转换为 []int 类型，
	//这会导致一个错误，因为 cachedPrimes 是 nil，而不能强制转换为切片---->解決:init一個初始cache
	primeInRange := calculator.Calculate(start, end)
	cachedPrimes, found := cacheObject.Get("primes")
	existingPrimes := cachedPrimes.([]int)
	return primeInRange, existingPrimes, found
}

/*func QueryCachePrimesInRange(start int, end int) ([]int, error) {
	cachedPrimes, _, found := calculateAndGetInterface(start, end)
	if !found {
		err := UpdateCachePrimeRange(start, end)
		if err != nil {
			return nil, err
		}
	}
	primesInRange := calculator.SearchInterval(cachedPrimes, start, end)
	return primesInRange, nil
}*/

// /辨認value與質數區間，有沒有可以對到的數字，全都有就不用更新，一旦缺少一個就更新
/*func UpdateCachePrimeRange(start int, end int) error {
	primeInRange, existingPrimes, _ := calculateAndGetInterface(start, end)
	updatedPrimes := mergeAndRemoveDuplicates(existingPrimes, primeInRange)
	cacheObject.Set("primes", updatedPrimes, cache.DefaultExpiration)
	return nil //找不到key
}*/
