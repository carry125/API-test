package database

import (
	"log"
	"test/server"
)

type IsPrime struct { //自定義輸出
	NumberIntervalStart int 
	NumberIntervalEnd   int 
	PrimeValues         string
}

func InsertPrimeValues(start int, end int, values string) {
	//table := server.DBlink.Table("is_primes")
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	tableIsPrime := IsPrime{ //用變數將類別實體化
		NumberIntervalStart: start,
		NumberIntervalEnd:   end,
		PrimeValues:         values,
	}
	tableInsert := transact.Debug().Create(&tableIsPrime)
	if tableInsert.Error != nil {
		transact.Rollback() //錯誤時返回上一動
		log.Fatal(tableInsert.Error)
	}
	transact.Commit() //使用commit才算是上傳這個事務
}
func CheckIfRepeatInsert(start int, end int) bool {
	var existingData IsPrime
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	if result := transact.Where("number_interval_start = ? AND number_interval_end = ?", start, end).First(&existingData); result.Error == nil {
		result.Rollback()
		return true
	}
	return false
}
func QueryInterval(start int, end int) []string {
	var primeValues []string
	transact := server.DateBaseConnection.Table("is_primes").Begin()
	result := transact.Select("prime_values").Where("number_interval_start = ? AND number_interval_end = ?", start, end).Pluck("prime_values", &primeValues)
	if result.Error != nil {
		return nil
	}
	return primeValues
}
