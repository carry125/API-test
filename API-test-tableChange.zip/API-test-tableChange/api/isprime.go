package api

import (
	"fmt"
	"strconv"
	"test/calculator"
	"test/database"

	"github.com/gin-gonic/gin"
)

func CheckAndInsertPrimeValues(c *gin.Context) {
	start := c.PostForm("numStart")
	end := c.PostForm("numEnd")
	numStart, err := strconv.Atoi(start)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numStart"})
		return
	}
	numEnd, err := strconv.Atoi(end)
	if err != nil {
		c.JSON(400, gin.H{"error": "Invalid value for numEnd"})
		return
	}
	if database.CheckIfRepeatInsert(numStart, numEnd) { //資料已存在，查詢並輸出
		primeValueToDatabase := database.QueryInterval(numStart, numEnd)
		c.JSON(200, primeValueToDatabase) //傳出去HTTP response，但其中的數據會是JSON
		//c.JSON(404, gin.H{"message": "資料已存在"})
	} else {
		primeValue := calculator.Calculate(numStart, numEnd)               //不存在就儲存於資料庫
		primeValueToDatabase := fmt.Sprint(primeValue)                     //數組轉字串
		database.InsertPrimeValues(numStart, numEnd, primeValueToDatabase) //將資料打包往資料庫傳送
		c.JSON(404, gin.H{"message": "資料已儲存"})
	}
}
